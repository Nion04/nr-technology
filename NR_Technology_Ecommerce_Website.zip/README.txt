NR Technology E-commerce Starter
================================

Included:
- Customer product catalog
- Search/category filter
- Product details
- Cart
- Customer name/phone/address checkout
- WhatsApp order message
- Simple Admin panel for add/edit/delete products
- Responsive mobile design
- NR Technology logo

Important:
This version stores products/cart in the browser's localStorage. It is ideal as a working prototype/demo.
For a real public shop where products added from your phone are visible to every customer, a shared online database/backend is required (e.g. Supabase/Firebase) plus hosting. WhatsApp ordering can remain direct without a payment gateway.

Admin password: 1234
WhatsApp number configured in index.html: 8801611299600
Change these values before public deployment if needed.
